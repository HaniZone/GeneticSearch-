﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace fringeSearch.Search
{
    class Genetic
    {
        private Node[,] Map;
        private Point S, G;
        private int Row, Col;
        private List<string> Fringe;
        private List<Point> Extended;
        private List<Point> Path;
        private List<string> Report;
        public List<List<int>> Diagram;
        //---------------------------
        private void SetHue()
        {
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Col; j++)
                {
                    Map[i, j].hue = Math.Abs(i - G.X) + Math.Abs(j - G.Y);
                }
            }
        }
        public void Init(String[] File)
        {
            Report = new List<string>();
            Extended = new List<Point>();
            Fringe = new List<string>();
            char[] split = { ' ' };
            List<string[]> types = new List<string[]>();
            Row = File.Length;
            for (int i = 0; i < Row; i++)
            {
                types.Add(File[i].Split(split));
            }
            Col = types[0].Length;
            Map = new Node[Row, Col];
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Col; j++)
                {
                    Map[i, j] = new Node(int.Parse(types[i][j]), 100000, int.MaxValue, 'N');
                    if (Map[i, j].type == 1) S = new Point(i, j);
                    if (Map[i, j].type == 2) G = new Point(i, j);
                }
            }
            SetHue();
            Diagram = new List<List<int>>();
        }
        //---------------------------
        private bool IsTarget(Point P)
        {
            return P == G;
        }
        private bool CanGo(Point P)
        {
            bool R = (((P.X >= 0) && (P.X < Row)) && ((P.Y >= 0) && (P.Y < Col)));
            if (R)
            {
                if (Map[P.X, P.Y].type >= 3) R = false;
            }
            if (R)
            {
                R = !Path.Exists(q => q.X == P.X && q.Y == P.Y);
            }
            return R;
        }
        private bool IsBetter(Point P, int C, char d)
        {
            if (CanGo(P))
            {
                if (Map[P.X, P.Y].cost > C)
                {
                    Map[P.X, P.Y].cost = C;
                    Map[P.X, P.Y].dir = d;
                    Map[P.X, P.Y].Visited = false;
                    return true;
                }
            }
            return false;
        }
        //---------------------------
        private Point Move(Point P, char d)
        {
            int x = (d == 'U') ? -1 : (d == 'D') ? +1 : 0;
            int y = (d == 'L') ? -1 : (d == 'R') ? +1 : 0;
            return new Point(P.X + x, P.Y + y);
        }
        //---------------------------
        private Point FindMin()
        {
            Point p = new Point();
            int min = int.MaxValue;
            int value = 0;
            for (int i = 0; i < Extended.Count; i++)
            {
                value = Map[Extended[i].X, Extended[i].Y].cost + Map[Extended[i].X, Extended[i].Y].hue;
                if (value < min && !Map[Extended[i].X, Extended[i].Y].Visited && CanGo(Extended[i]))
                {
                    min = value;
                    p = Extended[i];
                }
            }
            return p;
        }
        private List<List<Point>> Chromosomes;
        private List<int> Fitness;
        public void Genetic_Search()
        {
            int max_length = 2 * (Math.Abs(S.X - G.X) + Math.Abs(S.Y - G.Y));
            Chromosomes = new List<List<Point>>();
            Fitness = new List<int>();            
            int P1,P2;
            int x, y, brx, bry;
            List<Point> Parent1, Parent2, Child1, Child2;
            Random r = new Random((int)DateTime.Now.Ticks);
            int cnt;
            Point P, N = Point.Empty;
            int dir = -1;
            string report;
          
            Fringe.Add("Generate Population");
            for (int i = 0; i < 10; i++)
            {
                dir = r.Next(0,4);
                cnt = 0;
                Path = new List<Point>();
                P = new Point(S.X, S.Y);
                while (cnt < max_length && P != G)
                {
                    Path.Add(P);
                    cnt++;
                    do
                    {
                        switch (dir)
                        {
                            case 0: N = Move(P,'L'); break;
                            case 1: N = Move(P,'U'); break;
                            case 2: N = Move(P,'R'); break;
                            case 3: N = Move(P,'D'); break;
                        }
                        dir += r.Next(0, 3);
                        if (dir < 0) dir += 4;
                        dir %= 4;
                        bool flag = CanGo(Move(N, 'L')) || CanGo(Move(N, 'U')) || CanGo(Move(N, 'R')) || CanGo(Move(N, 'D'));
                        if (!flag)
                        {
                            Path.Clear();
                            Path.Add(S);
                            P = S;
                            N = P;
                            cnt = 1;
                        }
                    }while(!CanGo(N));
                    P = N;
                }
                if (P == G) Path.Add(G);
                Chromosomes.Add(Path);
            }
            //Fitness
            for (int j = 0; j < Chromosomes.Count; j++)
            {
                if (Chromosomes[j].Exists(q => q == G))
                {
                    Fitness.Add(-1*Chromosomes[j].Count);
                }
                else
                {
                    Fitness.Add(int.MinValue);
                }
            }
            report = "";
            for (int j = 0; j < Fitness.Count; j++)
            {
                report += Fitness[j].ToString() + " ";
            }
            Fringe.Add(report);
            //Iterate
            for (int i = 0; i < 10; i++)
            {
                Fringe.Add("Iteration " + i.ToString());                
                //Selection
                do
                {
                    P1 = r.Next(0, Chromosomes.Count);
                } while (Fitness[P1] == int.MinValue);
                do
                {
                    P2 = r.Next(0, Chromosomes.Count);
                } while (Fitness[P2] == int.MinValue || P1 == P2);
                Fringe.Add("Parents = {" + P1.ToString() + " , " + P2.ToString() + " }");
                Parent1 = Chromosomes[P1];
                Parent2 = Chromosomes[P2];
                //Crossover
                x = 1;
                y = Parent2.Count - 2;
                brx = bry = -1;
                while (y > 0 && bry < 0)
                {
                    x = 1;
                    while (x < Parent1.Count - 1)
                    {
                        if (Parent1[x] == Parent2[y])
                            break;
                        x++;
                    }
                    if (x < Parent1.Count - 1)
                    {
                        brx = x;
                        bry = y;
                    }
                    y--;
                }
                Child1 = new List<Point>();
                Child2 = new List<Point>();
                if (brx < 0) brx = 0;
                if (bry < 0) bry = 0;
                for (int j = 0; j < brx; j++)
                {
                    Child1.Add(Parent1[j]);
                }
                for (int j = 0; j < bry; j++)
                {
                    Child2.Add(Parent2[j]);
                }
                for (int j = brx; j < Parent1.Count; j++)
                {
                    Child2.Add(Parent1[j]);
                }
                for (int j = bry; j < Parent2.Count; j++)
                {
                    Child1.Add(Parent2[j]);
                }
                Chromosomes.Add(Child1);
                Chromosomes.Add(Child2);
                Fitness.Add(-1 * Child1.Count);
                Fitness.Add(-1 * Child2.Count);
                Fringe.Add("Fitness of Children = { " + (-1 * Child1.Count).ToString() + " , " + (-1 * Child2.Count).ToString() + " }");
                //Balance
                for (int j = 0; j < 2; j++)
                {
                    int min, pos;
                    min = 1;
                    pos = -1;
                    for (int k = 0; k < Chromosomes.Count; k++)
                    {
                        if (min > Fitness[k])
                        {
                            min = Fitness[k];
                            pos = k;
                        }
                    }
                    Chromosomes.RemoveAt(pos);
                    Fitness.RemoveAt(pos);
                }
                Fringe.Add("Balanced Population");
                report = "";
                List<int> dtmp = new List<int>();
                for (int j = 0; j < Fitness.Count; j++)
                {
                    report += Fitness[j].ToString() + " ";
                    dtmp.Add(Fitness[j]);
                }
                Diagram.Add(dtmp);
                Fringe.Add(report);
            }
        }
        //---------------------------
        public char GetDir(Point S, Point F)
        {
            char c = 'N';
            int x = 10 * (F.X - S.X);
            x += (F.Y - S.Y);
            switch (x)
            {
                case -10: c = 'U'; break;
                case +10: c = 'D'; break;
                case -1: c = 'L'; break;
                case +1: c = 'R'; break;
            }
            return c;
        }
        public string GetPath()
        {
            string Path = "";
            int max = int.MinValue;
            int pos = -1;
            Random r = new Random((int)DateTime.Now.Ticks);
            for (int i = 0; i < Fitness.Count; i++)
            {
                if (max < Fitness[i])
                {
                    max = Fitness[i];
                    pos = i;
                }
                else if (max == Fitness[i])
                {
                    if (r.Next(0, 100) >= 50)
                        pos = i;
                }
            }            
            Point P , N;
            char c = 'N';
            for (int i = 0; i < Chromosomes[pos].Count - 1; i++)
            {
                P = Chromosomes[pos][i];
                N = Chromosomes[pos][i + 1];
                Path += GetDir(P, N).ToString();
            }                        
            return Path;
        }
        public List<Point> GetExtended()
        {
            return Extended;
        }
        public List<string> GetFringe()
        {
            return Fringe;
        }
    }
}
