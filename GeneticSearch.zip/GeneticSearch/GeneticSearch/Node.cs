﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace fringeSearch
{
    class Node
    {
        public int type;
        public int cost;
        public char dir;
        public int hue;
        public bool Visited;
        public Node(int t, int c, int h, char d)
        {
            type = t;
            cost = c;
            hue = h;
            dir = d;
            Visited = false;
        }
    }
}
