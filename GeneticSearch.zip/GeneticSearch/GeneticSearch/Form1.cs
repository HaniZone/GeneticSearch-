﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace fringeSearch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                tbFile.Text = dlg.FileName;
            }
        }

        
        private void btnGenetic_Click(object sender, EventArgs e)
        {
            var x = System.IO.File.ReadAllLines(tbFile.Text);
            Search.Genetic D = new Search.Genetic();
            D.Init(x);
            D.Genetic_Search();
            tbPath.Text = D.GetPath();
            List<string> fr = D.GetFringe();
            lbFringe.Items.Clear();
            for (int i = 0; i < fr.Count; i++)
            {
                lbFringe.Items.Add(fr[i]);
            }
            Form2 dlg = new Form2();
            dlg.Show();
            dlg.ShowDiagram(D.Diagram);            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
