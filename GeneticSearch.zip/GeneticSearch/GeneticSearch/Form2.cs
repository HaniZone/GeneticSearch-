﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace fringeSearch
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public void ShowDiagram(List<List<int>> d)
        {
            int min = int.MaxValue;
            int max = int.MinValue;
            for (int i = 0; i < d.Count; i++)
            {
                for (int j = 0; j < d[i].Count; j++)
                {
                    if (d[i][j] < min) min = d[i][j];
                    if (d[i][j] > max) max = d[i][j];
                }
            }
            Graphics g = this.CreateGraphics();
            int unit = (this.Height - 100) / (max - min);
            List<Color> C = new List<Color>();
            C.Add(Color.Black);
            C.Add(Color.PowderBlue);
            C.Add(Color.Bisque);
            C.Add(Color.Aquamarine);
            C.Add(Color.DeepPink);
            C.Add(Color.ForestGreen);
            C.Add(Color.Red);
            C.Add(Color.BlanchedAlmond);
            C.Add(Color.Yellow);
            C.Add(Color.Purple);
            int x = 0;
            int xunit = this.Width / 10;
            Point Start = new Point(0, 0);
            Point Destination = new Point();
            Pen PD = new Pen(Color.Gray);
            g.DrawLine(PD, 0, max * unit, this.Width, max * unit);
            for (int i = 0; i < d.Count; i++)
            {
                x = i;
                Brush P = new SolidBrush(C[i]);
                for (int j = 0; j < d[i].Count; j++)
                {
                    Destination.X = x;
                    Destination.Y = (max - d[i][j]) * unit;
                    g.FillEllipse(P, (float)Destination.X, (float)(Destination.Y + 2*i), (40f - 3.5f*i), (40f - 3.5f*i));
                    x += xunit;
                }
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
